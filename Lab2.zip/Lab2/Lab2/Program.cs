﻿//Grading ID: A6689
//Lab2
//Due date: 9/17/2017
//CIS 199-01
//This program with allow the user to enter two numbers and the program will calculate the 
//               sum, difference, product, division, and the mean of the two numbers. 


using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2
{
    class Program
    {
        static void Main(string[] args)
        {
            string firstNumberAsString;             //String for the first number that is entered
            double firstNumber;                     //Variable for the first number that is entered 
            string secondNumberAsString;            //String for the second number that is entered
            double secondNumber;                    //Variable for the second number that is entered 
            double sumNumber;                       //Variable for the sum of the two numbers
            double differenceNumber;                //Variable for the subtraction of the two numbers 
            double productNumber;                   //Variable for the product of the two numbers 
            double divideNumber;                    //Variable for the division of the two numbers
            double meanNumber;                      //Variable for the mean of the two numbers

            Console.Write("Enter your first number: ");
            firstNumberAsString = Console.ReadLine();
            firstNumber = double.Parse(firstNumberAsString);

            Console.Write("Enter your second number: ");
            secondNumberAsString = Console.ReadLine();
            secondNumber = double.Parse(secondNumberAsString);

            Console.WriteLine();

            sumNumber = firstNumber + secondNumber;
            differenceNumber = firstNumber - secondNumber;
            productNumber = firstNumber * secondNumber;
            divideNumber = firstNumber / secondNumber;
            meanNumber = (firstNumber + secondNumber) / 2;    

            Console.WriteLine($"{firstNumber:F3} + {secondNumber:F3} = {sumNumber:F3}");
            Console.WriteLine($"{firstNumber:F3} - {secondNumber:F3} = {differenceNumber:F3}");
            Console.WriteLine($"{firstNumber:F3} * {secondNumber:F3} = {productNumber:F3}");
            Console.WriteLine($"{firstNumber:F3} / {secondNumber:F3} = {divideNumber:F3}");
            Console.WriteLine("---Mean of");
            Console.WriteLine($"{firstNumber:F3} , {secondNumber:F3} = {meanNumber:F3}");

        
            
        
            
           
        }
    }
}
