﻿//Grading ID : A6689
//Program 1
//Due Date: 9/26/2017
//Course Section: CIS199-01
//This program will take the user input of their length, height, number of doors, number of windows,
//   and the number of coats you need. It will then calcuate how many gallons of paint you will need to
//   cover your walls. 

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to the Handy-Dandy Paint Estimator!");
            Console.WriteLine(); 

            double wallLength;                       //Length of the wall

            double wallHeight;                       //Height of the wall

            const double DOORSPACE = 20;             //Constant number for the size of the door
            int doorNumber;                          //How many doors the user will enter

            const double WINDOWSPACE = 15;           //Constant number of size of the window
            int windowNumber;                        //How many windows the user will enter

            int coatsPaint;                          //How many coats of paint the user will enter 

            double subTotal;                         //The Square foot of the room without the number of coats
            double doorSubtraction;                  //How many sqaure foot the doors take up 
            double windowSubtraction;                //How many sqaure foot the windows take up
            double totalSqaurefeet;                  //The total square footage
            double numberGallons;                    //exact number of gallons you need
            int gallonsToBuy;                        //the rounded whole number of gallons you need
            const double PAINTCOVERAGE = 350;        //How much a gallon of paint covers

            //Prompt the user to enter the Length
            Console.Write("Enter the total length of all the walls (in feet): ");
            wallLength = double.Parse(Console.ReadLine());

            //Prompt the user to enter the height
            Console.Write("Enter the height of the walls (in feet): ");
            wallHeight = double.Parse(Console.ReadLine());

            //Prompt the user to enter how many doors
            Console.Write("Enter the number of doors (non-neg int): ");
            doorNumber = int.Parse(Console.ReadLine());

            //prompt the user to enter how many windows
            Console.Write("Enter the number of windows (non-neg int): ");
            windowNumber = int.Parse(Console.ReadLine());

            //prompt the user to enter how many coats you will need
            Console.Write("Enter the number of coats of paint (non-neg int): ");
            coatsPaint = int.Parse(Console.ReadLine());

            doorSubtraction = DOORSPACE * doorNumber;                       //sqaure foot of the doors
            windowSubtraction = WINDOWSPACE * windowNumber;                 //sqaure foot of the windows
            subTotal = (wallLength * wallHeight) - (doorSubtraction + windowSubtraction);  //square foot of everything without the coats
            totalSqaurefeet = subTotal * coatsPaint;                        //total square foot
            numberGallons = totalSqaurefeet / PAINTCOVERAGE;                //exact number of gallons
            gallonsToBuy = (int)Math.Ceiling(numberGallons);                //rounded number of gallons

            Console.WriteLine();

            //This will output how many gallons you will need to paint
            Console.WriteLine($"You need a minimum of {numberGallons:F1} gallons of paint");
            Console.WriteLine($"You'll need to buy {gallonsToBuy} gallons, though"); 








        }
    }
}
