﻿//Grading ID: A6689
//Lab3
//Due Date: 9/24/2017
//CIS 199-01
//This program is going to pop up a GUI box and prompt the user to inter their
//   meal amount. Then it will take that amount and calculate how much the tip 
//   would be if they tipped 15, 18 or 20 percent. 


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            const double TIPRATE_LOW = 0.15;       //15% tip
            const double TIPRATE_MID = 0.18;       //18% tip
            const double TIPRATE_HIGH = 0.20;      //20% tip
            double mealAmount;                     //How much the meal was
            double tipLow;                         //Tip amount for the low tip
            double tipMid;                         //Tip amount for the mid tip
            double tipHigh;                        //Tip amount for the high tip

            //Take the input for the user
            mealAmount = double.Parse(mealtxt.Text);

            tipLow = mealAmount * TIPRATE_LOW;     //calculation for tip low
            tipMid = mealAmount * TIPRATE_MID;     //calculation for tip mid
            tipHigh = mealAmount * TIPRATE_HIGH;   //calculation for tip high

            TipLabelLow.Text = $"{tipLow:C}";      //Display tip low
            TiplabelMid.Text = $"{tipMid:C}";      //Display tip mid
            TipLabelHigh.Text = $"{tipHigh:C}";    //Display tip high

        }
    }
}
