﻿namespace Lab3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.mealtxt = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.TipLabelLow = new System.Windows.Forms.Label();
            this.TiplabelMid = new System.Windows.Forms.Label();
            this.TipLabelHigh = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(62, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(173, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Enter price of the meal:";
            // 
            // mealtxt
            // 
            this.mealtxt.Location = new System.Drawing.Point(254, 29);
            this.mealtxt.Name = "mealtxt";
            this.mealtxt.Size = new System.Drawing.Size(176, 26);
            this.mealtxt.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(194, 98);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "15%";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(194, 151);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 20);
            this.label3.TabIndex = 3;
            this.label3.Text = "18%";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(194, 211);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 20);
            this.label4.TabIndex = 4;
            this.label4.Text = "20%";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(184, 276);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(171, 41);
            this.button1.TabIndex = 8;
            this.button1.Text = "Calculate Tip";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // TipLabelLow
            // 
            this.TipLabelLow.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TipLabelLow.Location = new System.Drawing.Point(257, 89);
            this.TipLabelLow.Name = "TipLabelLow";
            this.TipLabelLow.Size = new System.Drawing.Size(172, 29);
            this.TipLabelLow.TabIndex = 9;
            // 
            // TiplabelMid
            // 
            this.TiplabelMid.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TiplabelMid.Location = new System.Drawing.Point(257, 142);
            this.TiplabelMid.Name = "TiplabelMid";
            this.TiplabelMid.Size = new System.Drawing.Size(172, 29);
            this.TiplabelMid.TabIndex = 10;
            // 
            // TipLabelHigh
            // 
            this.TipLabelHigh.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TipLabelHigh.Location = new System.Drawing.Point(257, 200);
            this.TipLabelHigh.Name = "TipLabelHigh";
            this.TipLabelHigh.Size = new System.Drawing.Size(172, 31);
            this.TipLabelHigh.TabIndex = 11;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(487, 345);
            this.Controls.Add(this.TipLabelHigh);
            this.Controls.Add(this.TiplabelMid);
            this.Controls.Add(this.TipLabelLow);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.mealtxt);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Lab3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox mealtxt;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label TipLabelLow;
        private System.Windows.Forms.Label TiplabelMid;
        private System.Windows.Forms.Label TipLabelHigh;
    }
}

