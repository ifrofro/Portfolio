﻿//Grading ID: A6689
//CIS 199-01
//Due : Sunday, November 12
//Lab 7
//This program will take 3 inputs from the user, the future amount, the interest rate, and the years. 
// It will then calculate how much you need to invest to be able to get to that future amount. This 
// program will use nested if statements along with Try Parse and a method. 
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab7
{
    public partial class Lab7 : Form
    {
        public Lab7()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double future;                            //variable for future amount 
            double interestRate;                      //variable for interest rate
            int years;                                //variable for years
            double value;                             //variable for the value

            if (double.TryParse(futureTextBox.Text, out future) && future >= 0)   //future cant be negative 
            {
                if(double.TryParse(interestRateTextBox.Text, out interestRate) && interestRate >= 0) //interest rate cant be negative
                {
                    if(int.TryParse(yearTextBox.Text, out years) && years >= 0)  //years cant be negative
                    {
                        value = CalcPresentValue(future, interestRate, years);  
                        presentValueTextBox.Text = $"{value:C}"; 
                    }
                }
            }
            else
                MessageBox.Show("Enter a valid future amount");

        }
        //method that delcares variables used for the math, they are identical to the ones above. 
        public static double CalcPresentValue(double future1, double interestRate1, int years1)
        {
            double denominator;           //variable I used for the denominator 
            double total;                 //variable for the total 
            denominator = Math.Pow((interestRate1 + 1), years1);
            total = future1 / denominator;
            return total;                 //returns the total value up to the value in the click handler
        }
            


        
    }
}
