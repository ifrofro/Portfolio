﻿//A6689
//Lab1
//due date: 9/2/2017
//CIS 199-01
//This program will tell you what my grading ID is and things about me

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1
{
    class Program
    {
        static void Main(string[] args)
        {
            System.Console.WriteLine("Grading ID:     A6689");
            System.Console.WriteLine("Hobbies:        Playing golf and video games");
            System.Console.WriteLine("Favorite Book:  I am number 4");
            System.Console.WriteLine("Favorite Movie: Talladega Nights");
       
    
        }
    }
}
