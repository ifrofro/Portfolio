﻿//Grading ID = A6689
//Program 2
//Sunday, October 22
//CIS 199-01
//This program will make the user type in their last name in the Text box and choose from 
//  one of the radio buttons whether they are a freshman, sophomore, junior or senior
//  and they will click the button to see when they can register for next semester

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prog2
{
    public partial class Program2 : Form
    {
        public Program2()
        {
            InitializeComponent();
        }

        private void registerButton_Click(object sender, EventArgs e)
        {
            const string SENIOR_DAY = "Friday, Nov. 3rd";        //the day seniors can reg.
            const string JUNIOR_DAY = "Monday, Nov. 6th";        //day when juniors can reg.
            const string SOPHOMORE_DAY1 = "Tuesday, Nov. 7th";   //day 1 of sophomore reg.
            const string SOPHOMPRE_DAY2 = "Wednesday, Nov. 8th"; //day 2 of sophomore reg.
            const string FRESHMEN_DAY1 = "Thursday, Nov. 9th";   //day 1 of freshmen reg.
            const string FRESHMEN_DAY2 = "Friday, Nov. 10th";    //day 2 of freshman reg. 
            const string TIME1 = "8:30 am";         //the first time slot 830am
            const string TIME2 = "10:00 am";        //second time slot 10am
            const string TIME3 = "11:30 am";        //third time slot 1130am             
            const string TIME4 = "2:00 pm";         //fourth time slot 200pm
            const string TIME5 = "4:00 pm";         //fifth time slot 400pm


            char letter;                            //single character variable 
            string time;                            //variable for the time of reg.
            string date;                            //variable for the date of the reg.

            letter = nameTextBox.Text[0];           
            letter = char.ToUpper(letter);
            if (seniorButton.Checked || juniorButton.Checked)
            {
                if (seniorButton.Checked)
                    date = SENIOR_DAY;
                else
                    date = JUNIOR_DAY;

                if (letter <= 'D')
                    time = TIME2;
                else if (letter <= 'I')
                    time = TIME3;
                else if (letter <= 'O')
                    time = TIME4;
                else if (letter <= 'S')
                    time = TIME5;
                else
                    time = TIME1; 
            }
            else
            {
                if (sophomoreButton.Checked)
                {
                    if (letter < 'G' || letter > 'S')
                        date = SOPHOMORE_DAY1;
                    else
                        date = SOPHOMPRE_DAY2;
                }
                else
                {
                    if (letter < 'G' || letter > 'S')
                        date = FRESHMEN_DAY1;
                    else
                        date = FRESHMEN_DAY2;
                }

                if (letter <= 'B')
                    time = TIME3;
                else if (letter <= 'D')
                    time = TIME4;
                else if (letter <= 'F')
                    time = TIME5;
                else if (letter <= 'I')
                    time = TIME1;
                else if (letter <= 'L')
                    time = TIME2;
                else if (letter <= 'O')
                    time = TIME3;
                else if (letter <= 'Q')
                    time = TIME4;
                else if (letter <= 'S')
                    time = TIME5;
                else if (letter <= 'V')
                    time = TIME1;
                else
                    time = TIME2; 
            }
            MessageBox.Show($"{date} at {time}");
            

        }   

    }
}
