﻿//Grading ID:    A6689
//Lab 6
//Due Date:   Sunday, October 29
//CIS 199-01
//This program will allow the user to input how many words a student typed. It will prompt the user
//    if they dont enter a number and tell them that what they entered was valid. Then it will output
//    a letter grade to tell them what grade they have received. 
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int wordsTyped;                               //variable for the input
            int[] wordsGrade = { 0, 16, 31, 51, 76 };     //variable for the array of words typed per min
            string[] grade = { "F", "D", "C", "B", "A" }; //variable for the arrow of grades 
            bool found = false;                           //boolean variable to make the input false
            bool inputValid = false;                      //boolean variable to make the input not valid
            string letterGrade = "F";                     //string for the letter grade for it to be output

            inputValid = int.TryParse(wordsTextBox.Text, out wordsTyped); //Try parse statement for the input
            if (inputValid && wordsTyped >= 0)                            //if its a valid statement 
            {
                int index = wordsGrade.Length - 1;                        //variable for the index

                while (index >= 0 && !found)
                {
                    if (wordsTyped >= wordsGrade[index])
                        found = true;
                    else
                        --index;
                }
                if (found)
                    letterGrade = grade[index];

                gradeLabel.Text = letterGrade;
            }
            else MessageBox.Show("Not a valid input!");
        }
    }
}
