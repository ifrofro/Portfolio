﻿//Grading ID: A6689
//Lab 5
//Sunday, October 22 2017
//CIS 199-01
//This program will use for loops to output stars into a pattern. There are 4 patterns
//    that will be outputted and they are all different. 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab5
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Pattern A");               
            Console.WriteLine();                          
            const int MAX_ROWS = 10;                      //constant of Max number of rows
            //outter loop for pattern A that starts out at row 1 and continues to go up till 10 
            for (int row = 1; row <= MAX_ROWS; row++)     
            {
                for (int star = 1; star <= row; star++) //Will start out at 1 star and continue   
                    Console.Write("*");                 //    to add stars till it begins to have more                 
                Console.WriteLine();                    //    stars than rows 
            }

            Console.WriteLine();
            Console.WriteLine("Pattern B");
            Console.WriteLine();
            //for loop for pattern b that will start at 10 rows and go down every time it runs
            //  then it goes into the inner loop and that will add stars that is equal to how 
            //  many rows there are. 
            for (int row = MAX_ROWS; row >= 1; row--)                 //variable row 
            {
                for (int star = 1; star <= row; star++)               //variable star
                    Console.Write("*");
                Console.WriteLine();
            }
            Console.WriteLine();
            Console.WriteLine("Pattern C");
            Console.WriteLine();
            //Pattern C will start out at the 10th row but will add spaces to the row as well as
            //   put stars too. It takes the Max number of rows then subtracts that for the row 
            //   its on and that equals to how much spaces it will out put. The stars will do the
            //   same thing as the previous patterns. 
            for (int row = MAX_ROWS; row >= 1; row--)                  // variable row 
            {
                for (int space = 1; space <= MAX_ROWS - row; space++)  // variable space 
                    Console.Write(" ");

                for (int star = 1; star <= row; star++)               // variable star 
                    Console.Write("*");
                Console.WriteLine();
            }
            Console.WriteLine();
            Console.WriteLine("Pattern D");
            Console.WriteLine();
            //This will do the exact same thing as pattern C but will start at a different
            //  number of rows
            for (int row = 1; row <= MAX_ROWS; row++)                   //variable row
            {
                for (int space = 1; space <= MAX_ROWS - row; space++)  //variable space 
                    Console.Write(" ");
                for (int star = 1; star <= row; star++)                //variable star
                    Console.Write("*");
                Console.WriteLine(); 
            }





         }
    }
}
